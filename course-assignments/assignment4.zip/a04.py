class Node:
    pass 

class Ring:
    pass 

if __name__ == '__main__': 
    r = Ring()
    # r.insert(1, 1)
    r.insert(0, 1)
    r.insert(0, 2)
    r.insert(1, 3)
    r.insert(7, 5)  # different behavrior since it's a ring! 
    print(r)
